Subject: Your Playbook and a next step

Hi,

Thanks for asking for the Playbook. If you want a small win this month, reply with two notes:
- Which tools do you use daily.
- One task that repeats and hurts.

I will send a safe two week plan you can try.

Tom

---

Follow up 1 - two days later
Subject: A small win we can ship fast

Hi,

If you share the task and tools I can outline a two week pilot plan. One page. No fluff.

Tom

---

Follow up 2 - ten days later
Subject: Did the Playbook help

Hi,

If you tried a small step, I would like to hear how it went. If not, send one task and I will write a plan for it.

Tom
