# Brand brief
Name: Green AI and Automation
Voice: calm, clear, practical.
Copy style: short sentences. verbs first. no filler. no em dashes.
Colors: dark background, soft teal and soft violet accents. high contrast text.
Shapes: rounded corners. soft glow for focus.
Motion: short and smooth.
Icons: simple geometric.
