Free items, two week pilot, proof lab, and a care plan.
